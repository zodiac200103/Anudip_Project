package com.bank.config;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection 
{

    private static Connection connection;

    static {
        try {
            String url = "jdbc:mysql://localhost:3306/banking_system";
            String user = "root";
            String password = "root1234";

            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Database connected successfully.");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() 
    {
        return connection;
    }
}
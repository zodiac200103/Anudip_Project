package com.bank.service;

import java.sql.*;

import com.bank.config.DBConnection;

public class AuthService {

    public int login(String username, String password, String role) {
        String sql = "SELECT user_id FROM users WHERE username = ? AND password = ? AND role = ?";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, role);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("user_id");
                rs.close();
                ps.close();
                return id;
            }

            rs.close();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return -1;
    }

    public void registerUser(String name, String email, String username, String password, String mobile, String address) {
        String userSql = "INSERT INTO users(name, email, username, password, role) VALUES (?, ?, ?, ?, 'USER')";
        String profileSql = "INSERT INTO profile(user_id, mobile, address) VALUES (?, ?, ?)";

        try {
            Connection con = DBConnection.getConnection();
            con.setAutoCommit(false);

            PreparedStatement ps1 = con.prepareStatement(userSql, Statement.RETURN_GENERATED_KEYS);
            ps1.setString(1, name);
            ps1.setString(2, email);
            ps1.setString(3, username);
            ps1.setString(4, password);
            ps1.executeUpdate();

            ResultSet rs = ps1.getGeneratedKeys();
            int userId = 0;

            if (rs.next()) {
                userId = rs.getInt(1);
            }

            PreparedStatement ps2 = con.prepareStatement(profileSql);
            ps2.setInt(1, userId);
            ps2.setString(2, mobile);
            ps2.setString(3, address);
            ps2.executeUpdate();

            con.commit();
            con.setAutoCommit(true);

            System.out.println("User registered successfully.");

            rs.close();
            ps1.close();
            ps2.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
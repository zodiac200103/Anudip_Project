package com.bank.service;

import java.sql.*;

import com.bank.config.DBConnection;

public class UserService {

	public void viewProfile(int userId) {
	    String sql = """
	        SELECT u.name, u.email, u.username, p.mobile, p.address
	        FROM users u
	        LEFT JOIN profile p ON u.user_id = p.user_id
	        WHERE u.user_id = ?
	    """;

	    try {
	        Connection con = DBConnection.getConnection();
	        PreparedStatement ps = con.prepareStatement(sql);

	        ps.setInt(1, userId);

	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {

	            System.out.println("\n========= USER PROFILE =========");

	            System.out.printf("%-15s %-25s %-15s %-15s %-20s\n",
	                    "Name", "Email", "Username", "Mobile", "Address");

	            System.out.println("--------------------------------------------------------------------------");

	            System.out.printf("%-15s %-25s %-15s %-15s %-20s\n",
	                    rs.getString("name"),
	                    rs.getString("email"),
	                    rs.getString("username"),
	                    rs.getString("mobile"),
	                    rs.getString("address"));

	        } else {
	            System.out.println("User not found.");
	        }

	        rs.close();
	        ps.close();

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

    public void updateProfile(int userId, String mobile, String address) {
        String sql = "UPDATE profile SET mobile = ?, address = ? WHERE user_id = ?";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, mobile);
            ps.setString(2, address);
            ps.setInt(3, userId);

            ps.executeUpdate();
            System.out.println("Profile updated successfully.");

            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void addAccount(int userId, String accountNumber, double openingBalance) {
        String sql = "INSERT INTO account(user_id, account_number, balance) VALUES (?, ?, ?)";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, userId);
            ps.setString(2, accountNumber);
            ps.setDouble(3, openingBalance);

            ps.executeUpdate();
            System.out.println("Account added successfully.");

            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewAccounts(int userId) {
        String sql = "SELECT * FROM account WHERE user_id = ?";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, userId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println(
                    "Account ID: " + rs.getInt("account_id") +
                    " | Account No: " + rs.getString("account_number") +
                    " | Balance: " + rs.getDouble("balance")
                );
            }

            rs.close();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void transferMoney(int userId, int senderAccountId, int receiverAccountId, double amount) {
        String checkSql = "SELECT balance FROM account WHERE account_id = ? AND user_id = ?";
        String receiverSql = "SELECT account_id FROM account WHERE account_id = ?";
        String deductSql = "UPDATE account SET balance = balance - ? WHERE account_id = ?";
        String addSql = "UPDATE account SET balance = balance + ? WHERE account_id = ?";
        String txSql = "INSERT INTO bank_transaction(sender_account_id, receiver_account_id, amount) VALUES (?, ?, ?)";

        try {
            Connection con = DBConnection.getConnection();
            con.setAutoCommit(false);

            PreparedStatement check = con.prepareStatement(checkSql);
            check.setInt(1, senderAccountId);
            check.setInt(2, userId);

            ResultSet rs = check.executeQuery();

            if (!rs.next()) {
                System.out.println("Sender account not found or does not belong to you.");
                con.rollback();
                con.setAutoCommit(true);
                return;
            }

            double balance = rs.getDouble("balance");

            if (balance < amount) {
                System.out.println("Insufficient balance.");
                con.rollback();
                con.setAutoCommit(true);
                return;
            }

            PreparedStatement receiverCheck = con.prepareStatement(receiverSql);
            receiverCheck.setInt(1, receiverAccountId);
            ResultSet rs2 = receiverCheck.executeQuery();

            if (!rs2.next()) {
                System.out.println("Receiver account not found.");
                con.rollback();
                con.setAutoCommit(true);
                return;
            }

            PreparedStatement deduct = con.prepareStatement(deductSql);
            deduct.setDouble(1, amount);
            deduct.setInt(2, senderAccountId);
            deduct.executeUpdate();

            PreparedStatement add = con.prepareStatement(addSql);
            add.setDouble(1, amount);
            add.setInt(2, receiverAccountId);
            add.executeUpdate();

            PreparedStatement tx = con.prepareStatement(txSql);
            tx.setInt(1, senderAccountId);
            tx.setInt(2, receiverAccountId);
            tx.setDouble(3, amount);
            tx.executeUpdate();

            con.commit();
            con.setAutoCommit(true);

            System.out.println("Transfer successful.");

            rs.close();
            rs2.close();
            check.close();
            receiverCheck.close();
            deduct.close();
            add.close();
            tx.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void viewTransactions(int accountId) {
        String sql = """
            SELECT * FROM bank_transaction
            WHERE sender_account_id = ? OR receiver_account_id = ?
        """;

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, accountId);
            ps.setInt(2, accountId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println(
                    "Transaction ID: " + rs.getInt("transaction_id") +
                    " | From: " + rs.getInt("sender_account_id") +
                    " | To: " + rs.getInt("receiver_account_id") +
                    " | Amount: " + rs.getDouble("amount") +
                    " | Date: " + rs.getTimestamp("transaction_date")
                );
            }

            rs.close();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void checkBalance(int userId, int accountId) {
        String sql = "SELECT balance FROM account WHERE account_id = ? AND user_id = ?";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, accountId);
            ps.setInt(2, userId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                System.out.println("Balance: " + rs.getDouble("balance"));
            } else {
                System.out.println("Account not found.");
            }

            rs.close();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
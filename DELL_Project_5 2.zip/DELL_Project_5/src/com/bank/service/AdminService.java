package com.bank.service;

import java.sql.*;

import com.bank.config.DBConnection;

public class AdminService {

    public void viewUsers() {
        String sql = "SELECT user_id, name, email, username, role FROM users";

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println(
                    rs.getInt("user_id") + " | " +
                    rs.getString("name") + " | " +
                    rs.getString("email") + " | " +
                    rs.getString("username") + " | " +
                    rs.getString("role")
                );
            }

            rs.close();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteUser(int adminId, int targetUserId) {
        String logSql = "INSERT INTO admin_log(admin_id, action, target_user_id) VALUES (?, 'DELETE_USER', ?)";
        String deleteSql = "DELETE FROM users WHERE user_id = ? AND role = 'USER'";

        try {
            Connection con = DBConnection.getConnection();
            con.setAutoCommit(false);

            PreparedStatement ps1 = con.prepareStatement(logSql);
            ps1.setInt(1, adminId);
            ps1.setInt(2, targetUserId);
            ps1.executeUpdate();

            PreparedStatement ps2 = con.prepareStatement(deleteSql);
            ps2.setInt(1, targetUserId);

            int rows = ps2.executeUpdate();

            if (rows > 0) {
                con.commit();
                System.out.println("User deleted successfully.");
            } else {
                con.rollback();
                System.out.println("User not found or cannot delete admin.");
            }

            con.setAutoCommit(true);

            ps1.close();
            ps2.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updatePassword(int adminId, int targetUserId, String newPassword) {
        String updateSql = "UPDATE users SET password = ? WHERE user_id = ? AND role = 'USER'";
        String logSql = "INSERT INTO admin_log(admin_id, action, target_user_id) VALUES (?, 'UPDATE_PASSWORD', ?)";

        try {
            Connection con = DBConnection.getConnection();
            con.setAutoCommit(false);

            PreparedStatement ps1 = con.prepareStatement(updateSql);
            ps1.setString(1, newPassword);
            ps1.setInt(2, targetUserId);

            int rows = ps1.executeUpdate();

            if (rows > 0) {
                PreparedStatement ps2 = con.prepareStatement(logSql);
                ps2.setInt(1, adminId);
                ps2.setInt(2, targetUserId);
                ps2.executeUpdate();

                con.commit();
                ps2.close();

                System.out.println("Password updated successfully.");
            } else {
                con.rollback();
                System.out.println("User not found.");
            }

            con.setAutoCommit(true);
            ps1.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
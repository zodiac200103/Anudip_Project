package com.bank.main;

import java.util.Scanner;

import com.bank.config.DBConnection;
import com.bank.service.AdminService;
import com.bank.service.AuthService;
import com.bank.service.UserService;

public class Main {

    public static void main(String[] args) {

        DBConnection.getConnection();

        Scanner sc = new Scanner(System.in);

        AuthService auth = new AuthService();
        AdminService admin = new AdminService();
        UserService user = new UserService();

        while (true) {
        	System.out.println("\n==========================");
            System.out.println("\n===== BANKING SYSTEM =====");
        	System.out.println("\n==========================");
            System.out.println("1. Admin Login");
            System.out.println("2. User Login");
            System.out.println("3. Register User");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {

                case 1 -> {
                	System.out.println("\n=================");
                	System.out.println("\n====ADMIN LOGIN====");
                	System.out.println("\n=================");

                    System.out.print("Admin Username: ");
                    String username = sc.nextLine();

                    System.out.print("Admin Password: ");
                    String password = sc.nextLine();

                    int adminId = auth.login(username, password, "ADMIN");

                    if (adminId == -1) {
                        System.out.println("Invalid admin login.");
                    } else {
                        adminMenu(sc, admin, adminId);
                    }
                }

                case 2 -> {
                	System.out.println("\n=================");
                	System.out.println("\n====USER LOGIN====");
                	System.out.println("\n=================");
                    System.out.print("Username: ");
                    String username = sc.nextLine();

                    System.out.print("Password: ");
                    String password = sc.nextLine();

                    int userId = auth.login(username, password, "USER");

                    if (userId == -1) {
                        System.out.println("Invalid user login.");
                    } else {
                        userMenu(sc, user, userId);
                    }
                }

                case 3 -> {
                	System.out.println("\n========================");
                	System.out.println("\n====USER REGISTERATION====");
                	System.out.println("\n========================");
                    System.out.print("Name: ");
                    String name = sc.nextLine();

                    System.out.print("Email: ");
                    String email = sc.nextLine();

                    System.out.print("Username: ");
                    String username = sc.nextLine();

                    System.out.print("Password: ");
                    String password = sc.nextLine();

                    System.out.print("Mobile: ");
                    String mobile = sc.nextLine();

                    System.out.print("Address: ");
                    String address = sc.nextLine();

                    auth.registerUser(name, email, username, password, mobile, address);
                }

                case 4 -> {
                    System.out.println("Thank you.");
                    sc.close();
                    return;
                }

                default -> System.out.println("Invalid choice.");
            }
        }
    }

    public static void adminMenu(Scanner sc, AdminService admin, int adminId) {

        while (true) {
        	System.out.println("\n======================");
            System.out.println("\n===== ADMIN MENU =====");
        	System.out.println("\n======================");
            System.out.println("1. View Users");
            System.out.println("2. Delete User");
            System.out.println("3. Update User Password");
            System.out.println("4. Logout");
            System.out.print("Enter choice: ");

            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1 -> admin.viewUsers();

                case 2 -> {
                    System.out.print("Enter User ID to delete: ");
                    int userId = sc.nextInt();
                    sc.nextLine();

                    admin.deleteUser(adminId, userId);
                }

                case 3 -> {
                    System.out.print("Enter User ID: ");
                    int userId = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter New Password: ");
                    String newPassword = sc.nextLine();

                    admin.updatePassword(adminId, userId, newPassword);
                }

                case 4 -> {
                    System.out.println("Admin logged out.");
                    return;
                }

                default -> System.out.println("Invalid choice.");
            }
        }
    }

    public static void userMenu(Scanner sc, UserService user, int userId) {

        while (true) {
        	System.out.println("\n=====================");
            System.out.println("\n===== USER MENU =====");
        	System.out.println("\n=====================");
            System.out.println("1. View Profile");
            System.out.println("2. Update Profile");
            System.out.println("3. Add Account");
            System.out.println("4. View Accounts");
            System.out.println("5. Transfer Money");
            System.out.println("6. View Transactions");
            System.out.println("7. Check Balance");
            System.out.println("8. Logout");
            System.out.print("Enter choice: ");

            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1 -> user.viewProfile(userId);

                case 2 -> {
                    System.out.print("Mobile: ");
                    String mobile = sc.nextLine();

                    System.out.print("Address: ");
                    String address = sc.nextLine();

                    user.updateProfile(userId, mobile, address);
                }

                case 3 -> {
                    System.out.print("Account Number: ");
                    String accountNumber = sc.nextLine();

                    System.out.print("Opening Balance: ");
                    double balance = sc.nextDouble();
                    sc.nextLine();

                    user.addAccount(userId, accountNumber, balance);
                }

                case 4 -> user.viewAccounts(userId);

                case 5 -> {
                    System.out.print("Sender Account ID: ");
                    int sender = sc.nextInt();

                    System.out.print("Receiver Account ID: ");
                    int receiver = sc.nextInt();

                    System.out.print("Amount: ");
                    double amount = sc.nextDouble();
                    sc.nextLine();

                    user.transferMoney(userId, sender, receiver, amount);
                }

                case 6 -> {
                    System.out.print("Account ID: ");
                    int accountId = sc.nextInt();
                    sc.nextLine();

                    user.viewTransactions(accountId);
                }

                case 7 -> {
                    System.out.print("Account ID: ");
                    int accountId = sc.nextInt();
                    sc.nextLine();

                    user.checkBalance(userId, accountId);
                }

                case 8 -> {
                    System.out.println("User logged out.");
                    return;
                }

                default -> System.out.println("Invalid choice.");
            }
        }
    }
}